import React, { useState, useEffect } from 'react';
import { AnimatePresence } from 'framer-motion';
import ChatHeader from './components/ChatHeader';
import Sidebar from './components/Sidebar';
import ChatMessages from './components/ChatMessages';
import ChatInput from './components/ChatInput';
import EmptyState from './components/EmptyState';
import WebContainer from './components/WebContainer';
import GeometricShapes from './components/GeometricShapes';
import { Thread, Message } from './types';
import { createSampleThreads, generateId } from './utils/mockData';

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [threads, setThreads] = useState<Thread[]>([]);
  const [activeThreadId, setActiveThreadId] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [theme, setTheme] = useState<'theme-ultra-dark' | 'theme-light'>('theme-ultra-dark');
  const [webContainer, setWebContainer] = useState({
    isOpen: false,
    url: '',
    content: '',
    title: 'Web Preview'
  });

  // Initialize with sample data
  useEffect(() => {
    const sampleThreads = createSampleThreads();
    setThreads(sampleThreads);
    setActiveThreadId(sampleThreads[0].id);
    
    // Set initial theme class
    document.body.classList.add('theme-ultra-dark');
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === 'theme-ultra-dark' ? 'theme-light' : 'theme-ultra-dark';
    setTheme(newTheme);
    document.body.classList.remove('theme-ultra-dark', 'theme-light');
    document.body.classList.add(newTheme);
  };

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const handleNewThread = () => {
    const newThread: Thread = {
      id: generateId(),
      title: 'New Conversation',
      messages: [],
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    setThreads([newThread, ...threads]);
    setActiveThreadId(newThread.id);
  };

  const handleDeleteThread = (threadId: string) => {
    const updatedThreads = threads.filter(thread => thread.id !== threadId);
    setThreads(updatedThreads);
    
    if (activeThreadId === threadId) {
      setActiveThreadId(updatedThreads.length > 0 ? updatedThreads[0].id : '');
    }
  };

  const openWebContainer = (options: { url?: string; content?: string; title?: string }) => {
    setWebContainer({
      isOpen: true,
      url: options.url || '',
      content: options.content || '',
      title: options.title || 'Web Preview'
    });
  };

  const closeWebContainer = () => {
    setWebContainer(prev => ({ ...prev, isOpen: false }));
  };

  const handleSendMessage = (content: string) => {
    if (!activeThreadId) return;
    
    // Create user message
    const userMessage: Message = {
      id: generateId(),
      type: 'user',
      content,
      status: 'complete',
      timestamp: new Date()
    };
    
    // Update thread with user message
    const updatedThreads = threads.map(thread => {
      if (thread.id === activeThreadId) {
        // Update thread title if it's the first message
        const title = thread.messages.length === 0 
          ? content.slice(0, 30) + (content.length > 30 ? '...' : '') 
          : thread.title;
        
        return {
          ...thread,
          title,
          messages: [...thread.messages, userMessage],
          updatedAt: new Date()
        };
      }
      return thread;
    });
    
    setThreads(updatedThreads);
    
    // Simulate assistant response
    setIsLoading(true);
    
    // Create initial assistant message with "thinking" status
    const assistantMessageId = generateId();
    const initialAssistantMessage: Message = {
      id: assistantMessageId,
      type: 'assistant',
      content: '',
      status: 'thinking',
      timestamp: new Date(),
      thinking: "I'm processing your request..."
    };
    
    // Add initial assistant message
    setThreads(threads => 
      threads.map(thread => 
        thread.id === activeThreadId 
          ? {
              ...thread,
              messages: [...thread.messages, initialAssistantMessage],
              updatedAt: new Date()
            }
          : thread
      )
    );
    
    // Simulate thinking process with updates
    const thinkingSteps = [
      "Analyzing your question...",
      "Searching for relevant information...",
      "Formulating a comprehensive response...",
      "Finalizing the answer..."
    ];
    
    let stepIndex = 0;
    const thinkingInterval = setInterval(() => {
      if (stepIndex < thinkingSteps.length) {
        setThreads(threads => 
          threads.map(thread => 
            thread.id === activeThreadId 
              ? {
                  ...thread,
                  messages: thread.messages.map(msg => 
                    msg.id === assistantMessageId 
                      ? { ...msg, thinking: thinkingSteps[stepIndex] }
                      : msg
                  ),
                }
              : thread
          )
        );
        stepIndex++;
      } else {
        clearInterval(thinkingInterval);
      }
    }, 1000);
    
    // Simulate response delay
    setTimeout(() => {
      clearInterval(thinkingInterval);
      
      // Generate mock response based on user message
      let responseContent = '';
      
      if (content.toLowerCase().includes('hello') || content.toLowerCase().includes('hi')) {
        responseContent = "Hello! How can I assist you today?";
      } else if (content.toLowerCase().includes('code') || content.toLowerCase().includes('example')) {
        responseContent = `Here's an example code snippet:

\`\`\`javascript
function calculateSum(a, b) {
  return a + b;
}

// Example usage
const result = calculateSum(5, 10);
console.log(result); // 15
\`\`\`

You can modify this to suit your specific needs.`;

        // Open web container with code example
        setTimeout(() => {
          openWebContainer({
            content: `function calculateSum(a, b) {
  return a + b;
}

// Example usage
const result = calculateSum(5, 10);
console.log(result); // 15`,
            title: 'Code Example'
          });
        }, 500);
      } else if (content.toLowerCase().includes('web') || content.toLowerCase().includes('preview')) {
        responseContent = "I've opened a web preview for you to see the result.";
        
        // Open web container with a sample website
        setTimeout(() => {
          openWebContainer({
            url: 'https://example.com',
            title: 'Web Preview'
          });
        }, 500);
      } else {
        responseContent = "I understand your question. Let me help you with that. What specific details would you like me to elaborate on?";
      }
      
      // Update assistant message with completed response
      setThreads(threads => 
        threads.map(thread => 
          thread.id === activeThreadId 
            ? {
                ...thread,
                messages: thread.messages.map(msg => 
                  msg.id === assistantMessageId 
                    ? { 
                        ...msg, 
                        content: responseContent,
                        status: 'complete',
                        thinking: undefined
                      }
                    : msg
                ),
              }
            : thread
        )
      );
      
      setIsLoading(false);
    }, 4000);
  };

  // Get active thread
  const activeThread = threads.find(thread => thread.id === activeThreadId);
  const activeMessages = activeThread?.messages || [];

  return (
    <div className="h-screen flex flex-col bg-pure-black text-white" style={{ backgroundColor: 'var(--pure-black)', color: 'var(--text-primary)' }}>
      <ChatHeader 
        toggleSidebar={toggleSidebar} 
        sidebarOpen={sidebarOpen} 
        theme={theme}
        toggleTheme={toggleTheme}
      />
      
      <GeometricShapes />
      
      <div className="flex-1 flex overflow-hidden">
        <AnimatePresence>
          {sidebarOpen && (
            <Sidebar
              isOpen={sidebarOpen}
              threads={threads}
              activeThreadId={activeThreadId}
              onSelectThread={setActiveThreadId}
              onNewThread={handleNewThread}
              onDeleteThread={handleDeleteThread}
            />
          )}
        </AnimatePresence>
        
        <div className="flex-1 flex flex-col overflow-hidden w-full bg-pure-black" style={{ backgroundColor: 'var(--pure-black)' }}>
          {activeMessages.length > 0 ? (
            <ChatMessages messages={activeMessages} />
          ) : (
            <EmptyState />
          )}
          
          <ChatInput onSendMessage={handleSendMessage} isLoading={isLoading} />
        </div>
      </div>
      
      <WebContainer 
        isOpen={webContainer.isOpen}
        onClose={closeWebContainer}
        url={webContainer.url}
        content={webContainer.content}
        title={webContainer.title}
      />
    </div>
  );
};

export default App;
