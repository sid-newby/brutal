export type MessageType = 'user' | 'assistant' | 'system';
export type MessageStatus = 'complete' | 'thinking' | 'error';

export interface Message {
  id: string;
  type: MessageType;
  content: string;
  status: MessageStatus;
  timestamp: Date;
  parentId?: string;
  thinking?: string;
  children?: Message[];
}

export interface Thread {
  id: string;
  title: string;
  messages: Message[];
  createdAt: Date;
  updatedAt: Date;
  temperature?: number; // Optional temperature setting for the thread
}

export interface WebContainerOptions {
  url?: string;
  content?: string;
  title?: string;
}

// Default settings
export const DEFAULT_SETTINGS = {
  temperature: 0, // Set temperature to zero by default
  maxTokens: 4096,
  topP: 1,
  frequencyPenalty: 0,
  presencePenalty: 0
};
